//
//  ViewController.h
//  testBase
//
//  Created by ljg on 15-2-27.
//  Copyright (c) 2015年 ljg. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseVC.h"
@interface ViewController : BaseVC


@end

