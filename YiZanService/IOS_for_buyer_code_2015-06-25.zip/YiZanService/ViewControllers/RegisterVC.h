//
//  RegisterVC.h
//  YiZanService
//
//  Created by ljg on 15-3-20.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import "BaseVC.h"

@interface RegisterVC : BaseVC
@property(nonatomic,strong)UIViewController *tagVC;
@property (nonatomic,assign)int comFrom;

@end
