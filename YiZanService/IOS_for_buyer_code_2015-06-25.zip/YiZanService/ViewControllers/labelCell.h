//
//  labelCell.h
//  YiZanService
//
//  Created by zzl on 15/6/1.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface labelCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UIButton *mbt_a;

@property (weak, nonatomic) IBOutlet UIButton *mbt_b;

@property (weak, nonatomic) IBOutlet UIButton *mbt_c;
@property (weak, nonatomic) IBOutlet UIButton *mbt_d;

@end
