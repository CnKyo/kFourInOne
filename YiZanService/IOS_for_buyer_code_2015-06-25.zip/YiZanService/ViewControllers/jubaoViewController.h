//
//  jubaoViewController.h
//  YiZanService
//
//  Created by 密码为空！ on 15/4/24.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import "BaseVC.h"

@interface jubaoViewController : BaseVC


@property (nonatomic,assign) int    mId;
@property (nonatomic,assign) int    mtype;//1 商品,2服务人员

@property (nonatomic,assign) SOrder *sss;

@property (nonatomic,assign) int    xxx;

@end
