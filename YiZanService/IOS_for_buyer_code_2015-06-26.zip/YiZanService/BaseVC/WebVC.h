//
//  WebVC.h
//  YiZanService
//
//  Created by zzl on 15/3/29.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import "BaseVC.h"

@interface WebVC : BaseVC

@property (nonatomic,strong) NSString*  mName;
@property (nonatomic,strong) NSString*  mUrl;

@end
