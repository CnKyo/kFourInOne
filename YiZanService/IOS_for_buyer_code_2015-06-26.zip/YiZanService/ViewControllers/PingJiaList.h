//
//  PingJiaList.h
//  YiZanService
//
//  Created by zzl on 15/3/30.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import "BaseVC.h"

@interface PingJiaList : BaseVC

@property (nonatomic,strong) SGoods*   mGoods;
@property (nonatomic,strong) SStaff*   mStaff;

@end
