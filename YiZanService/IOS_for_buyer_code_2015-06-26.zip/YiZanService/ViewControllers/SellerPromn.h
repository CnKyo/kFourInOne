//
//  SellerPromn.h
//  YiZanService
//
//  Created by zzl on 15/5/18.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import "BaseVC.h"

@interface SellerPromn : BaseVC

@property (nonatomic,assign)    int mSellerid;

@end
