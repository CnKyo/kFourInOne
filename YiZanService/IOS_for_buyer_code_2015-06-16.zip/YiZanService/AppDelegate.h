//
//  AppDelegate.h
//  YiZanService
//
//  Created by ljg on 15-3-18.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
-(void)gotoLogin;

@end

