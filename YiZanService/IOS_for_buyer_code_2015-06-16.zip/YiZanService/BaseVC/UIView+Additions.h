//
//  UIView+Additions.h
//  7. 事件响应传递
//
//  Created by HCW on 14-3-15.
//  Copyright (c) 2014年 HCW. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UIView (Additions)

-(UIViewController *)viewController;

@end
