//
//  NSString+CheckEmpty.h
//  YiZanService
//
//  Created by ljg on 15-3-19.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (CheckEmpty)
-(BOOL)isEmpty;//字符串对象不为空的情况下才能调用---检测字符串是否为空

@end
