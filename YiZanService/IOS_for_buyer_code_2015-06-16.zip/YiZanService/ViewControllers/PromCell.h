//
//  PromCell.h
//  YiZanService
//
//  Created by zzl on 15/5/19.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PromCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *mdesc;
@property (weak, nonatomic) IBOutlet UILabel *mexp;
@property (weak, nonatomic) IBOutlet UILabel *mno;

@end
