//
//  OrderDetailVC.h
//  YiZanService
//
//  Created by ljg on 15-3-26.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import "BaseVC.h"

@interface OrderDetailVC : BaseVC
@property (nonatomic,strong)SOrder *tempOrder;
@end
