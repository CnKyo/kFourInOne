//
//  PingJiaCell.h
//  YiZanService
//
//  Created by zzl on 15/3/30.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PingJiaCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *mhead;
@property (weak, nonatomic) IBOutlet UILabel *mPhone;
@property (weak, nonatomic) IBOutlet UILabel *mlevel;
@property (weak, nonatomic) IBOutlet UIView *mmidimg;
@property (weak, nonatomic) IBOutlet UILabel *mtime;

@property (weak, nonatomic) IBOutlet UILabel *mcontext;
@end
