//
//  SellerPromCell.m
//  YiZanService
//
//  Created by zzl on 15/5/18.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import "SellerPromCell.h"

@implementation SellerPromCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
