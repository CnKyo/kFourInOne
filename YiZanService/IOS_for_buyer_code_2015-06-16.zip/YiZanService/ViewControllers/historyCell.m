//
//  historyCell.m
//  YiZanService
//
//  Created by zzl on 15/6/1.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import "historyCell.h"

@implementation historyCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
