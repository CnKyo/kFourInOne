//
//  WaiterDetailVC.h
//  YiZanService
//
//  Created by ljg on 15-3-24.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import "BaseVC.h"

@interface WaiterDetailVC : BaseVC

@property (nonatomic,strong)SStaff *sellerStaff;

@property (nonatomic,assign) int   xxx;
@end
