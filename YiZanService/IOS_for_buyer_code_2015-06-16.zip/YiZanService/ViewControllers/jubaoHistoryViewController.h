//
//  jubaoHistoryViewController.h
//  YiZanService
//
//  Created by 密码为空！ on 15/6/1.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import "BaseVC.h"

@interface jubaoHistoryViewController : BaseVC

@end
