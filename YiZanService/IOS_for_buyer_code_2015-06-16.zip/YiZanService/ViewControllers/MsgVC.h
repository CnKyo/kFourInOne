//
//  MsgVC.h
//  YiZanService
//
//  Created by zzl on 15/4/1.
//  Copyright (c) 2015年 zywl. All rights reserved.
//

#import "BaseVC.h"

@interface MsgVC : BaseVC

@end
